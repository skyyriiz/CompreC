sudo apt install libzip-dev -y
